Scraper._u = [
    'STUNNING SEÑOR',
    'Marble'
]