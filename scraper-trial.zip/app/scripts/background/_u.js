Scraper._u = [
    'STUNNING SEÑOR',
    'Pew Pew'
]